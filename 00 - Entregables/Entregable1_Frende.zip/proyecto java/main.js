const username = document.getElementById("username");
username.textContent = prompt ("Por favor ingrese su nombre");
console.log(`Bienvenido ${username.textContent}`)


var FrontHeight = document.getElementById("FrontHeight");
FrontHeight.textContent = prompt ("Ingresar Front Height > 50.0 mm");

while(FrontHeight.textContent < 50) {
    FrontHeight.textContent = prompt ("Por Favor ingresar Front Height > 50.0 mm ")
}
var FrontHeight_num = parseFloat(FrontHeight.textContent)
console.log((`La altura adelante es de ${FrontHeight.textContent} mm`))


var RearHeight = document.getElementById("RearHeight");
RearHeight.textContent = prompt ("Ingresar Rear Height > 50.0 mm");

while(RearHeight.textContent < 50) {
    RearHeight.textContent = prompt ("Por favor ingresar Front Height > 50.0 mm")
}
var ReartHeight_num = parseFloat(RearHeight.textContent)
console.log((`La altura atras es de ${RearHeight.textContent} mm`))


function CalculadoraBalance (a, b) {  //por el momento es solo una funcion primitiva del calculo del balace, solo es para test
    return (a + b) / 2;
}
console.log(`El balance de tu auto es de ${CalculadoraBalance(ReartHeight_num, FrontHeight_num)}%`)

const balanceResult = document.getElementById("balanceResult");
balanceResult.textContent = CalculadoraBalance(ReartHeight_num, FrontHeight_num);




/*document.querySelector('button[id="LowFH"]').addEventListener('click', NewFH() {console.log('monedaD')})
    function NewFH() {
        return  FrontHeight_num - 0.1 
    }
    FrontHeight.textContent = NewFH()
    var FrontHeight_num = parseFloat(FrontHeight.textContent)
    console.log((`La nueva altura adelante es de ${FrontHeight.textContent} mm`))
} 

var num1 = 1.3;
num2 = num1 + 0.1;
console.log(num2)
*/
